============================================================
                        IMPORTANT
============================================================

Before editing the config, please take a look at the wiki.
You can find information about all configs, and it's options there.
The wiki is located at: https://github.com/tristankechlo/ToolLeveling/wiki

